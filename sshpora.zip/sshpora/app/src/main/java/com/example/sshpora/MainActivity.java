package com.example.sshpora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//создаем интенты
        final Intent intent = new Intent(this, SecondActivity.class);
       //назодим наш список из разметки первого кона
        ListView list = findViewById(R.id.matList);
       //создаем адаптер для списка
        list.setAdapter(new ArrayAdapter<>(this, R.layout.custom_main,
                getResources().getStringArray(R.array.mat)));

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            //в переопределнном методе пропиываем слушатель нажатия по элементу списка
            @Override
            public void onItemClick(AdapterView<?> parent, View itemClicked, int position, long id) {
               //передаем интенты во второе активити для открытия html файла
                intent.putExtra("key", ((TextView)itemClicked).getText()+".html");
                startActivity(intent);
            }
        });

    }
}
