package com.example.sshpora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class SecondActivity extends AppCompatActivity {
//создаем второе окно
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
//находим webview из разметки второго кона
        WebView textView = findViewById(R.id.textView);
        //получаем интент из первого окна
        textView.loadUrl("file:///android_asset/" + getIntent().getStringExtra("key"));
    }
}